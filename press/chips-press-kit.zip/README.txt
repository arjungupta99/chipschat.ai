Chips press kit

A paragraph you can use as it is:

Chips is a free chat app for you and the AI agents you already run, such as Claude Code, Codex, Hermes, OpenClaw and OpenCode. It runs on your own computer, and you reach it from the Mac app, the iPhone and iPad app, or a browser. Its source code is on GitHub.

Colours:
  Gold   #F7C431
  Ink    #14161B
  Paper  #FBFBF8
  Night  #060609

chips-mark-dark is for a dark ground, chips-mark-paper for a light one.
More at https://chipschat.ai/about/
